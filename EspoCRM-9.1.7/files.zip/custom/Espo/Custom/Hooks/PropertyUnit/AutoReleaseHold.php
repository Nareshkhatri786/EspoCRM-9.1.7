<?php

namespace Espo\Custom\Hooks\PropertyUnit;

use Espo\ORM\Entity;

class AutoReleaseHold extends \Espo\Core\Hooks\Base
{
    public static $order = 10;

    public function afterSave(Entity $entity, array $options = [])
    {
        if (
            $entity->get('status') === 'Hold' &&
            $entity->get('holdExpiryDate') &&
            strtotime($entity->get('holdExpiryDate')) < strtotime('today')
        ) {
            $entity->set('status', 'Available');
            $entity->set('assignedLeadId', null);
            $entity->set('holdExpiryDate', null);
            $this->getEntityManager()->saveEntity($entity);
        }
    }
}